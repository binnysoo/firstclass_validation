from django.apps import AppConfig


class ProfileValidateConfig(AppConfig):
    name = 'profile_validate'
